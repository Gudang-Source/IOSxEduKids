//
//  LoginController.swift
//  EduKids
//
//  Created by imac-12 on 1/17/20.
//  Copyright © 2020 bietsy. All rights reserved.
//

import UIKit

class LoginController: UIViewController {
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBAction func btnLogin(_ sender: Any) {
        let dict = NSDictionary(contentsOfFile: Bundle.main.path(forResource: "user", ofType: "plist")!)
        let email = dict!["email"] as? String
        let password = dict!["password"] as? String
        
        if txtEmail.text != email {
            let alert = UIAlertController(title: "Alert", message: "Surat elektronik tidak boleh kosong atau tidak terdaftar !", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(ok)
            present(alert, animated: true)
        }
        else if txtEmail.text == email && txtPassword.text != password {
            let alert = UIAlertController(title: "Alert", message: "Password salah !", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(ok)
            present(alert, animated: true)
        }
        else{
            print("Berhasil Masuk !")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if(segue.identifier=="login"){
            let kirim = segue.destination as! DashboardController
            kirim.email = txtEmail.text
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
